export type PlatformName = "ebay" | "poshmark" | "mercari" | "depop" | "grailed" | "etsy" | "shopify" | "tiktok";

export type ProductCondition =
  | "New With Tags (NWT)"
  | "New Without Tags (NWOT)"
  | "Like New / Excellent Used Condition (EUC)"
  | "Good Used Condition (GUC)"
  | "Fair Condition";

export interface SyncRecord {
  listed: boolean;
  listedPrice?: number;
  listedUrl?: string;
  syncedAt?: string;
  syncStatus: "idle" | "loading" | "success" | "error";
  syncLog?: string;
}

export interface ResellerProduct {
  id: string;
  title: string;
  brand: string;
  size: string;
  condition: ProductCondition;
  buyCost: number;
  suggestedPrice: number;
  sku: string;
  upc?: string;
  imageUrl: string;
  description: string;
  platforms: Record<PlatformName, SyncRecord>;
  createdAt: string;
}
