BOSS LISTERS AI — Starter Kit
==============================
1. Open MASTER_PROMPT.txt
2. Copy ALL of it
3. Paste into Google AI Studio (aistudio.google.com) with Gemini 1.5 Pro
4. Also upload src/types.ts and src/data.ts as context files
5. Gemini will output the full working codebase

After Gemini generates the files:
  npm install
  npm run dev
